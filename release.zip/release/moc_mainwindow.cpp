/****************************************************************************
** Meta object code from reading C++ file 'mainwindow.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.3.0)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../mainwindow.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'mainwindow.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.3.0. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
struct qt_meta_stringdata_MainWindow_t {
    QByteArrayData data[67];
    char stringdata[924];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_MainWindow_t, stringdata) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_MainWindow_t qt_meta_stringdata_MainWindow = {
    {
QT_MOC_LITERAL(0, 0, 10),
QT_MOC_LITERAL(1, 11, 13),
QT_MOC_LITERAL(2, 25, 0),
QT_MOC_LITERAL(3, 26, 13),
QT_MOC_LITERAL(4, 40, 13),
QT_MOC_LITERAL(5, 54, 13),
QT_MOC_LITERAL(6, 68, 13),
QT_MOC_LITERAL(7, 82, 13),
QT_MOC_LITERAL(8, 96, 13),
QT_MOC_LITERAL(9, 110, 13),
QT_MOC_LITERAL(10, 124, 13),
QT_MOC_LITERAL(11, 138, 13),
QT_MOC_LITERAL(12, 152, 13),
QT_MOC_LITERAL(13, 166, 13),
QT_MOC_LITERAL(14, 180, 13),
QT_MOC_LITERAL(15, 194, 13),
QT_MOC_LITERAL(16, 208, 13),
QT_MOC_LITERAL(17, 222, 13),
QT_MOC_LITERAL(18, 236, 13),
QT_MOC_LITERAL(19, 250, 13),
QT_MOC_LITERAL(20, 264, 13),
QT_MOC_LITERAL(21, 278, 13),
QT_MOC_LITERAL(22, 292, 13),
QT_MOC_LITERAL(23, 306, 13),
QT_MOC_LITERAL(24, 320, 13),
QT_MOC_LITERAL(25, 334, 13),
QT_MOC_LITERAL(26, 348, 13),
QT_MOC_LITERAL(27, 362, 13),
QT_MOC_LITERAL(28, 376, 13),
QT_MOC_LITERAL(29, 390, 13),
QT_MOC_LITERAL(30, 404, 13),
QT_MOC_LITERAL(31, 418, 13),
QT_MOC_LITERAL(32, 432, 13),
QT_MOC_LITERAL(33, 446, 13),
QT_MOC_LITERAL(34, 460, 13),
QT_MOC_LITERAL(35, 474, 13),
QT_MOC_LITERAL(36, 488, 13),
QT_MOC_LITERAL(37, 502, 13),
QT_MOC_LITERAL(38, 516, 13),
QT_MOC_LITERAL(39, 530, 13),
QT_MOC_LITERAL(40, 544, 13),
QT_MOC_LITERAL(41, 558, 13),
QT_MOC_LITERAL(42, 572, 13),
QT_MOC_LITERAL(43, 586, 13),
QT_MOC_LITERAL(44, 600, 13),
QT_MOC_LITERAL(45, 614, 13),
QT_MOC_LITERAL(46, 628, 13),
QT_MOC_LITERAL(47, 642, 13),
QT_MOC_LITERAL(48, 656, 13),
QT_MOC_LITERAL(49, 670, 13),
QT_MOC_LITERAL(50, 684, 13),
QT_MOC_LITERAL(51, 698, 13),
QT_MOC_LITERAL(52, 712, 13),
QT_MOC_LITERAL(53, 726, 13),
QT_MOC_LITERAL(54, 740, 13),
QT_MOC_LITERAL(55, 754, 13),
QT_MOC_LITERAL(56, 768, 13),
QT_MOC_LITERAL(57, 782, 13),
QT_MOC_LITERAL(58, 796, 13),
QT_MOC_LITERAL(59, 810, 13),
QT_MOC_LITERAL(60, 824, 13),
QT_MOC_LITERAL(61, 838, 13),
QT_MOC_LITERAL(62, 852, 13),
QT_MOC_LITERAL(63, 866, 13),
QT_MOC_LITERAL(64, 880, 13),
QT_MOC_LITERAL(65, 894, 13),
QT_MOC_LITERAL(66, 908, 15)
    },
    "MainWindow\0on_a1_clicked\0\0on_b1_clicked\0"
    "on_c1_clicked\0on_d1_clicked\0on_e1_clicked\0"
    "on_f1_clicked\0on_g1_clicked\0on_h1_clicked\0"
    "on_a2_clicked\0on_b2_clicked\0on_c2_clicked\0"
    "on_d2_clicked\0on_e2_clicked\0on_f2_clicked\0"
    "on_g2_clicked\0on_h2_clicked\0on_a3_clicked\0"
    "on_b3_clicked\0on_c3_clicked\0on_d3_clicked\0"
    "on_e3_clicked\0on_f3_clicked\0on_g3_clicked\0"
    "on_h3_clicked\0on_a4_clicked\0on_b4_clicked\0"
    "on_c4_clicked\0on_d4_clicked\0on_e4_clicked\0"
    "on_f4_clicked\0on_g4_clicked\0on_h4_clicked\0"
    "on_a5_clicked\0on_b5_clicked\0on_c5_clicked\0"
    "on_d5_clicked\0on_e5_clicked\0on_f5_clicked\0"
    "on_g5_clicked\0on_h5_clicked\0on_a6_clicked\0"
    "on_b6_clicked\0on_c6_clicked\0on_d6_clicked\0"
    "on_e6_clicked\0on_f6_clicked\0on_g6_clicked\0"
    "on_h6_clicked\0on_a7_clicked\0on_b7_clicked\0"
    "on_c7_clicked\0on_d7_clicked\0on_e7_clicked\0"
    "on_f7_clicked\0on_g7_clicked\0on_h7_clicked\0"
    "on_a8_clicked\0on_b8_clicked\0on_c8_clicked\0"
    "on_d8_clicked\0on_e8_clicked\0on_f8_clicked\0"
    "on_g8_clicked\0on_h8_clicked\0on_menu_clicked"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_MainWindow[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
      65,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    0,  339,    2, 0x08 /* Private */,
       3,    0,  340,    2, 0x08 /* Private */,
       4,    0,  341,    2, 0x08 /* Private */,
       5,    0,  342,    2, 0x08 /* Private */,
       6,    0,  343,    2, 0x08 /* Private */,
       7,    0,  344,    2, 0x08 /* Private */,
       8,    0,  345,    2, 0x08 /* Private */,
       9,    0,  346,    2, 0x08 /* Private */,
      10,    0,  347,    2, 0x08 /* Private */,
      11,    0,  348,    2, 0x08 /* Private */,
      12,    0,  349,    2, 0x08 /* Private */,
      13,    0,  350,    2, 0x08 /* Private */,
      14,    0,  351,    2, 0x08 /* Private */,
      15,    0,  352,    2, 0x08 /* Private */,
      16,    0,  353,    2, 0x08 /* Private */,
      17,    0,  354,    2, 0x08 /* Private */,
      18,    0,  355,    2, 0x08 /* Private */,
      19,    0,  356,    2, 0x08 /* Private */,
      20,    0,  357,    2, 0x08 /* Private */,
      21,    0,  358,    2, 0x08 /* Private */,
      22,    0,  359,    2, 0x08 /* Private */,
      23,    0,  360,    2, 0x08 /* Private */,
      24,    0,  361,    2, 0x08 /* Private */,
      25,    0,  362,    2, 0x08 /* Private */,
      26,    0,  363,    2, 0x08 /* Private */,
      27,    0,  364,    2, 0x08 /* Private */,
      28,    0,  365,    2, 0x08 /* Private */,
      29,    0,  366,    2, 0x08 /* Private */,
      30,    0,  367,    2, 0x08 /* Private */,
      31,    0,  368,    2, 0x08 /* Private */,
      32,    0,  369,    2, 0x08 /* Private */,
      33,    0,  370,    2, 0x08 /* Private */,
      34,    0,  371,    2, 0x08 /* Private */,
      35,    0,  372,    2, 0x08 /* Private */,
      36,    0,  373,    2, 0x08 /* Private */,
      37,    0,  374,    2, 0x08 /* Private */,
      38,    0,  375,    2, 0x08 /* Private */,
      39,    0,  376,    2, 0x08 /* Private */,
      40,    0,  377,    2, 0x08 /* Private */,
      41,    0,  378,    2, 0x08 /* Private */,
      42,    0,  379,    2, 0x08 /* Private */,
      43,    0,  380,    2, 0x08 /* Private */,
      44,    0,  381,    2, 0x08 /* Private */,
      45,    0,  382,    2, 0x08 /* Private */,
      46,    0,  383,    2, 0x08 /* Private */,
      47,    0,  384,    2, 0x08 /* Private */,
      48,    0,  385,    2, 0x08 /* Private */,
      49,    0,  386,    2, 0x08 /* Private */,
      50,    0,  387,    2, 0x08 /* Private */,
      51,    0,  388,    2, 0x08 /* Private */,
      52,    0,  389,    2, 0x08 /* Private */,
      53,    0,  390,    2, 0x08 /* Private */,
      54,    0,  391,    2, 0x08 /* Private */,
      55,    0,  392,    2, 0x08 /* Private */,
      56,    0,  393,    2, 0x08 /* Private */,
      57,    0,  394,    2, 0x08 /* Private */,
      58,    0,  395,    2, 0x08 /* Private */,
      59,    0,  396,    2, 0x08 /* Private */,
      60,    0,  397,    2, 0x08 /* Private */,
      61,    0,  398,    2, 0x08 /* Private */,
      62,    0,  399,    2, 0x08 /* Private */,
      63,    0,  400,    2, 0x08 /* Private */,
      64,    0,  401,    2, 0x08 /* Private */,
      65,    0,  402,    2, 0x08 /* Private */,
      66,    0,  403,    2, 0x08 /* Private */,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

void MainWindow::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        MainWindow *_t = static_cast<MainWindow *>(_o);
        switch (_id) {
        case 0: _t->on_a1_clicked(); break;
        case 1: _t->on_b1_clicked(); break;
        case 2: _t->on_c1_clicked(); break;
        case 3: _t->on_d1_clicked(); break;
        case 4: _t->on_e1_clicked(); break;
        case 5: _t->on_f1_clicked(); break;
        case 6: _t->on_g1_clicked(); break;
        case 7: _t->on_h1_clicked(); break;
        case 8: _t->on_a2_clicked(); break;
        case 9: _t->on_b2_clicked(); break;
        case 10: _t->on_c2_clicked(); break;
        case 11: _t->on_d2_clicked(); break;
        case 12: _t->on_e2_clicked(); break;
        case 13: _t->on_f2_clicked(); break;
        case 14: _t->on_g2_clicked(); break;
        case 15: _t->on_h2_clicked(); break;
        case 16: _t->on_a3_clicked(); break;
        case 17: _t->on_b3_clicked(); break;
        case 18: _t->on_c3_clicked(); break;
        case 19: _t->on_d3_clicked(); break;
        case 20: _t->on_e3_clicked(); break;
        case 21: _t->on_f3_clicked(); break;
        case 22: _t->on_g3_clicked(); break;
        case 23: _t->on_h3_clicked(); break;
        case 24: _t->on_a4_clicked(); break;
        case 25: _t->on_b4_clicked(); break;
        case 26: _t->on_c4_clicked(); break;
        case 27: _t->on_d4_clicked(); break;
        case 28: _t->on_e4_clicked(); break;
        case 29: _t->on_f4_clicked(); break;
        case 30: _t->on_g4_clicked(); break;
        case 31: _t->on_h4_clicked(); break;
        case 32: _t->on_a5_clicked(); break;
        case 33: _t->on_b5_clicked(); break;
        case 34: _t->on_c5_clicked(); break;
        case 35: _t->on_d5_clicked(); break;
        case 36: _t->on_e5_clicked(); break;
        case 37: _t->on_f5_clicked(); break;
        case 38: _t->on_g5_clicked(); break;
        case 39: _t->on_h5_clicked(); break;
        case 40: _t->on_a6_clicked(); break;
        case 41: _t->on_b6_clicked(); break;
        case 42: _t->on_c6_clicked(); break;
        case 43: _t->on_d6_clicked(); break;
        case 44: _t->on_e6_clicked(); break;
        case 45: _t->on_f6_clicked(); break;
        case 46: _t->on_g6_clicked(); break;
        case 47: _t->on_h6_clicked(); break;
        case 48: _t->on_a7_clicked(); break;
        case 49: _t->on_b7_clicked(); break;
        case 50: _t->on_c7_clicked(); break;
        case 51: _t->on_d7_clicked(); break;
        case 52: _t->on_e7_clicked(); break;
        case 53: _t->on_f7_clicked(); break;
        case 54: _t->on_g7_clicked(); break;
        case 55: _t->on_h7_clicked(); break;
        case 56: _t->on_a8_clicked(); break;
        case 57: _t->on_b8_clicked(); break;
        case 58: _t->on_c8_clicked(); break;
        case 59: _t->on_d8_clicked(); break;
        case 60: _t->on_e8_clicked(); break;
        case 61: _t->on_f8_clicked(); break;
        case 62: _t->on_g8_clicked(); break;
        case 63: _t->on_h8_clicked(); break;
        case 64: _t->on_menu_clicked(); break;
        default: ;
        }
    }
    Q_UNUSED(_a);
}

const QMetaObject MainWindow::staticMetaObject = {
    { &QMainWindow::staticMetaObject, qt_meta_stringdata_MainWindow.data,
      qt_meta_data_MainWindow,  qt_static_metacall, 0, 0}
};


const QMetaObject *MainWindow::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *MainWindow::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_MainWindow.stringdata))
        return static_cast<void*>(const_cast< MainWindow*>(this));
    return QMainWindow::qt_metacast(_clname);
}

int MainWindow::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 65)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 65;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 65)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 65;
    }
    return _id;
}
QT_END_MOC_NAMESPACE
